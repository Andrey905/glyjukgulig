import sys  # Импорт библиотек
import calendar
import locale
import sqlite3
import time
from datetime import datetime, date, time, timedelta, datetime as DT
from PyQt5.QtCore import Qt, QDate
from PyQt5 import QtCore, QtGui
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QDialog, QMainWindow, QListWidget
from PyQt5.QtGui import *
from des_Calendar import Ui_CalendarV2  # Подключение интерфейсов
from edit_or_delete_event_window import Ui_add_delete_edit
locale.setlocale(locale.LC_ALL, '')
locale.resetlocale()
global week_days  # Определение глобальных переменных
global months
global months_day
global current_date
global tek_znach
global add_or_update
add_or_update = 'update'
tek_znach = (14, 1)
current_date = datetime.today()
week_days = ("понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье")
months = ('Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь',\
                  'Октябрь', 'Ноябрь', 'Декабрь')
months_day = ('Января', 'Февраля', 'Марта', 'Апреля', 'Майя', 'Июня', 'Июля', 'Августа', 'Сентября',\
                  'Октября', 'Ноября', 'Декабря')




class Calendar(QWidget, Ui_CalendarV2):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.setFixedSize(900, 620)
        self.ad = Add_delete_edit_event(self)
        self.list_events_all_day = [self.events_all_day_Monday, self.events_all_day_Tuesday,
                                    self.events_all_day_Wednesday, \
                                    self.events_all_day_Thursday, self.events_all_day_Friday,
                                    self.events_all_day_Saturday,
                                    self.events_all_day_Sunday]
        self.list_events_day = [self.events_Monday, self.events_Tuesday, self.events_Wednesday, \
                                self.events_Thursday, self.events_Friday, self.events_Saturday,
                                self.events_Sunday]
        self.con = sqlite3.connect("CalendarBase.db")  # Подключение к БД
        self.set_date()
        self.add_events.clicked.connect(self.create_window)
        self.but_seve.setIcon(QIcon('documentsave.png'))
        self.but_seve.resize(35, 25)
        self.but_seve.clicked.connect(self.seve_file_with_event)
        self.date_from.setCalendarPopup(True)
        self.date_before.setCalendarPopup(True)
        self.date_from.setDate(current_date)
        self.date_before.setDate(current_date)

        # Режим день
        self.pushButton_today_day.clicked \
            .connect(lambda: self.clicked_pushButton_previous_today_next('today'))
        self.pushButton_previous_day.clicked \
            .connect(lambda: self.clicked_pushButton_previous_today_next('previous'))
        self.pushButton_next_day.clicked \
            .connect(lambda: self.clicked_pushButton_previous_today_next('next'))
        self.events_day.itemDoubleClicked.connect(lambda: self.update_event(0, self.events_day,\
                                                                            current_date))
        self.events_all_day.itemClicked.connect(lambda: self.update_event(1, self.events_all_day,\
                                                                          current_date))
        # Режим год
        self.pushButton_today_year.clicked \
            .connect(lambda: self.clicked_pushButton_previous_today_next_year('today'))
        self.pushButton_previous_year.clicked \
            .connect(lambda: self.clicked_pushButton_previous_today_next_year('previous'))
        self.pushButton_next_year.clicked \
            .connect(lambda: self.clicked_pushButton_previous_today_next_year('next'))
        self.renewal_clendar()
        # Режим неделя
        self.pushButton_today_week.clicked \
            .connect(lambda: self.clicked_pushButton_previous_today_next_week('today'))
        self.pushButton_previous_week.clicked \
            .connect(lambda: self.clicked_pushButton_previous_today_next_week('previous'))
        self.pushButton_next_week.clicked \
            .connect(lambda: self.clicked_pushButton_previous_today_next_week('next'))
        self.days_in_week = self.create_week_day()
        self.list_events_day[0].itemActivated.connect( \
            lambda: self.update_event(0, self.list_events_day[0], self.days_in_week[0]))
        self.list_events_all_day[0].itemActivated.connect( \
            lambda: self.update_event(1, self.list_events_all_day[0], self.days_in_week[0]))
        self.list_events_day[1].itemActivated.connect( \
            lambda: self.update_event(0, self.list_events_day[1], self.days_in_week[1]))
        self.list_events_all_day[1].itemActivated.connect( \
            lambda: self.update_event(1, self.list_events_all_day[1], self.days_in_week[1]))
        self.list_events_day[2].itemActivated.connect( \
            lambda: self.update_event(0, self.list_events_day[2], self.days_in_week[2]))
        self.list_events_all_day[2].itemActivated.connect( \
            lambda: self.update_event(1, self.list_events_all_day[2], self.days_in_week[2]))
        self.list_events_day[3].itemActivated.connect( \
            lambda: self.update_event(0, self.list_events_day[3], self.days_in_week[3]))
        self.list_events_all_day[3].itemActivated.connect( \
            lambda: self.update_event(1, self.list_events_all_day[3], self.days_in_week[3]))
        self.list_events_day[4].itemActivated.connect( \
            lambda: self.update_event(0, self.list_events_day[4], self.days_in_week[4]))
        self.list_events_all_day[4].itemActivated.connect( \
            lambda: self.update_event(1, self.list_events_all_day[4], self.days_in_week[4]))
        self.list_events_day[5].itemActivated.connect( \
            lambda: self.update_event(0, self.list_events_day[5], self.days_in_week[5]))
        self.list_events_all_day[5].itemActivated.connect(
            lambda: self.update_event(1, self.list_events_all_day[5], self.days_in_week[5]))
        self.list_events_day[6].itemActivated.connect( \
            lambda: self.update_event(0, self.list_events_day[6], self.days_in_week[6]))
        self.list_events_all_day[6].itemActivated.connect(
            lambda: self.update_event(1, self.list_events_all_day[6], self.days_in_week[6]))
        # Режим месяц
        self.pushButton_today_month.clicked \
            .connect(lambda: self.clicked_pushButton_previous_today_next_month('today'))
        self.pushButton_previous_month.clicked \
            .connect(lambda: self.clicked_pushButton_previous_today_next_month('previous'))
        self.pushButton_next_month.clicked \
            .connect(lambda: self.clicked_pushButton_previous_today_next_month('next'))
        self.calendarWidget_month.clicked.connect(self.showdate)

    def seve_file_with_event(self):
        date_fr_str = self.date_from.text().replace('.', '-')
        date_be_str = self.date_before.text().replace('.', '-')
        year_fr = date_fr_str[6] + date_fr_str[7] + date_fr_str[8] + date_fr_str[9]
        month_fr = date_fr_str[3] + date_fr_str[4]
        day_fr = date_fr_str[0] + date_fr_str[1]
        date_fr = date(int(year_fr), int(month_fr), int(day_fr))
        year_be = date_be_str[6] + date_be_str[7] + date_be_str[8] + date_be_str[9]
        month_be = date_be_str[3] + date_be_str[4]
        day_be = date_be_str[0] + date_be_str[1]
        date_be = date(int(year_be), int(month_be), int(day_be))
        con = sqlite3.connect("CalendarBase.db")  # Подключение к БД
        cur = con.cursor()  # Создание курсора
        a = (date_be - date_fr).days
        file = open("event.txt", 'w')
        if a < 0:
            a = 0
        for i in range(a + 1):
            current_date_ = date_fr + timedelta(i)
            current_date_str = current_date_.strftime('%Y-%m-%d')
            events_all_day_list = []
            events_not_all_day_list = []
            result = cur.execute("""SELECT event_def, date_time, period, is_all_day, type_id
                FROM event
                WHERE date(date_time) = date(?)
                            order by date_time ASC""", (current_date_str,)).fetchall()
            month_day = months_day[current_date_.month - 1]
            if result:
                def type_event_update(type_id):
                    result2 = cur.execute("""SELECT type_name FROM type""").fetchall()
                    return result2[type_id][0]
                for i in range(len(result)):
                    if result[i][3] == 0:
                        events_not_all_day_list.append(result[i][0] + ', ' + result[i][1][-5] +\
                                                       result[i][1][-4] + result[i][1][-3]\
                                                       + result[i][1][-2] + result[i][1][-1] +\
                                                       ', ' + type_event_update(result[i][3]))
                    else:
                        events_all_day_list.append(
                            str(result[i][0]) + ', ' + type_event_update(result[i][4]))
                file.write(str(current_date_.day) + ' ' + month_day + ' ' + \
                         str(current_date_.year) + ' ' + 'г.' + '\n')
                file.write('' + '\n')
                if events_not_all_day_list:
                    for strk in events_not_all_day_list:
                        file.write(strk + '\n')
                file.write('' + '\n')
                if events_all_day_list:
                    file.write('Весь день:' + '\n')
                    for strk in events_all_day_list:
                        file.write(strk + '\n')
                file.write('' + '\n' + '' + '\n')
        file.close()

    def create_week_day(self):
        days_in_week = []
        day = current_date.weekday()
        for i in range(7):
            days = timedelta(day - i)
            week_day = current_date - days
            days_in_week.append(week_day)
        sorted(days_in_week)
        return days_in_week

    def set_date(self):
        self.days_in_week = self.create_week_day()
        month = months[current_date.month - 1]
        month_day = months_day[current_date.month - 1]
        self.day_month_year_day.setFont(QtGui.QFont("Calibri", 24, QtGui.QFont.Bold))
        self.day_month_year_day.setText(str(current_date.day) + ' ' + month_day + ' ' + \
                                        str(current_date.year) + ' ' + 'г.')
        self.week_day.setFont(QtGui.QFont("Calibri", 18, QtGui.QFont.Bold))
        self.week_day.setText(week_days[current_date.weekday()])
        self.event_output()
        self.event_output_week()
        self.day_month_year_year.setFont(QtGui.QFont("Calibri", 24, QtGui.QFont.Bold))
        self.day_month_year_year.setText(str(current_date.year))
        self.renewal_clendar()
        self.day_month_year_week.setFont(QtGui.QFont("Calibri", 24, QtGui.QFont.Bold))
        self.day_month_year_week.setText(str(month) + ' ' +\
                                    str(current_date.year) + ' ' + 'г.')
        list_week_days = [self.Monday_day, self.Tuesday_day, self.Wednesday_day, self.Thursday_day,\
                          self.Friday_day, self.Saturday_day, self.Sunday_day]
        day = current_date.weekday()
        for i in range(7):
            days = timedelta(day - i)
            week_day = current_date - days
            list_week_days[i].setText(str(week_day.day))
        self.day_month_year_month.setFont(QtGui.QFont("Calibri", 24, QtGui.QFont.Bold))
        self.day_month_year_month.setText(str(current_date.day) + ' ' + str(month_day) + ' ' + \
                                        str(current_date.year) + ' ' + 'г.')
        self.calendarWidget_month.setCurrentPage(current_date.year, current_date.month)
        self.calendarWidget_month.setSelectedDate(current_date)

    # Функции дня
    def clicked_pushButton_previous_today_next(self, value):  # Функция которая переключает на
        if value == 'previous':                               # предыдущий, текущий и следующий день
            one_day = timedelta(1)
            globals()["current_date"] = current_date - one_day
        if value == 'today':
            globals()["current_date"] = datetime.today()
        if value == 'next':
            one_day = timedelta(1)
            globals()["current_date"] = current_date + one_day
        self.set_date()

    def event_output(self):  # Вывод событий
        self.cur = self.con.cursor()
        date_ = current_date.strftime('%Y-%m-%d')
        events_all_day_list = []
        events_not_all_day_list = []
        result = self.cur.execute("""SELECT ev.event_def, ev.date_time, ev.period, ev.is_all_day
          FROM event ev, type tp
            WHERE ev.type_id = tp.type_id
              AND date(ev.date_time) = date(?)
                  order by date_time ASC""", (date_,)).fetchall()
        for i in range(len(result)):
            if result[i][3] == 0:
                events_not_all_day_list.append(result[i][1][-5] + result[i][1][-4]
                                               + result[i][1][-3] + result[i][1][-2]\
                                               + result[i][1][-1] + '\n' + result[i][0]\
                                               + '\n' + '_' * 120)
            else:
                events_all_day_list.append(str(len(events_all_day_list) + 1) + ') ' + result[i][0])
        self.events_all_day.clear()
        self.events_day.clear()
        self.events_all_day.setFont(QtGui.QFont("Calibri", 18, QtGui.QFont.Bold))
        self.events_day.setFont(QtGui.QFont("Calibri", 18, QtGui.QFont.Bold))
        self.events_all_day.addItems(events_all_day_list)
        self.events_day.addItems(events_not_all_day_list)

    # Функции года
    def renewal_clendar(self):
        list_month = [self.month_1, self.month_2, self.month_3, self.month_4, self.month_5,
                      self.month_6, self.month_7, self.month_8, self.month_9, self.month_10,
                      self.month_11, self.month_12]
        for i in range(len(list_month)):
            list_month[i].setDateRange(datetime.today(), datetime.today())
            list_month[i].setCurrentPage(current_date.year, i + 1)

    def add_or_subtract_one_year(self, date_, sign):  # Функция добовляющая или отнимающая один год
        year = date_.year
        if year % 4 == 0 and year % 100 != 0 or year % 400 == 0:
            if date_ == date(year, 2, 29):
                if sign == '+':
                    return date(year + 1, 2, 28)
                if sign == '-':
                    return date(year - 1, 2, 28)
            else:
                if sign == '+':
                    return date(year + 1, date_.month, date_.day)
                if sign == '-':
                    return date(year - 1, date_.month, date_.day)
        else:
            if sign == '+':
                return date(year + 1, date_.month, date_.day)
            if sign == '-':
                return date(year - 1, date_.month, date_.day)

    def clicked_pushButton_previous_today_next_year(self, value):  # Функция которая переключает на
        if value == 'previous':                               # предыдущий, текущий и следующий год
            globals()["current_date"] = self.add_or_subtract_one_year(current_date, '-')
        if value == 'today':
            globals()["current_date"] = datetime.today()
        if value == 'next':
            globals()["current_date"] = self.add_or_subtract_one_year(current_date, '+')
        self.set_date()

    # Функции недели
    def clicked_pushButton_previous_today_next_week(self, value):  # Функция которая переключает на
        if value == 'previous':                              # предыдущую, текущую и следующую неделю
            seven_day = timedelta(7)
            globals()["current_date"] = current_date - seven_day
        if value == 'today':
            globals()["current_date"] = datetime.today()
        if value == 'next':
            seven_day = timedelta(7)
            globals()["current_date"] = current_date + seven_day
        self.set_date()

    def event_output_week(self):  # Вывод событий
        self.cur = sqlite3.connect("CalendarBase.db").cursor()  # Подключение к БД и создание курсора
        day = current_date.weekday()
        for j in range(7):
            events_all_day_list = []
            events_not_all_day_list = []
            days = timedelta(day - j)
            week_day = current_date - days
            date_ = week_day.strftime('%Y-%m-%d')
            result = self.cur.execute("""SELECT ev.event_def, ev.date_time, ev.period, ev.is_all_day
                      FROM event ev, type tp
                        WHERE ev.type_id = tp.type_id
                          AND date(ev.date_time) = date(?)
                              order by date_time ASC""", (date_,)).fetchall()
            for i in range(len(result)):
                if result[i][3] == 0:
                    events_not_all_day_list.append(result[i][1][-5] + result[i][1][-4] + result[i][1][-3] \
                                                   + result[i][1][-2] + result[i][1][-1] \
                                                   + '\n' + result[i][0] + '\n')
                else:
                    events_all_day_list.append(str(len(events_all_day_list) + 1) + ') ' + result[i][0])

            self.list_events_all_day[j].clear()
            self.list_events_day[j].clear()
            self.list_events_all_day[j].setFont(QtGui.QFont("Calibri", 12, QtGui.QFont.Bold))
            self.list_events_day[j].setFont(QtGui.QFont("Calibri", 12, QtGui.QFont.Bold))
            self.list_events_all_day[j].addItems(events_all_day_list)
            self.list_events_day[j].addItems(events_not_all_day_list)

    # Функции месяца
    def clicked_pushButton_previous_today_next_month(self, value):  # Функция которая переключает на
        if value == 'previous':                               # предыдущий, текущий и следующий год
            globals()["current_date"] = self.add_months(-1)
        if value == 'today':
            globals()["current_date"] = datetime.today()
        if value == 'next':
            globals()["current_date"] = self.add_months(1)
        self.set_date()

    def showdate(self, date_):
        globals()["current_date"] = date(date_.year(), date_.month(), date_.day())
        self.set_date()

    def add_months(self, months):
        month = current_date.month - 1 + months
        year = current_date.year + month // 12
        month = month % 12 + 1
        day = min(current_date.day, calendar.monthrange(year, month)[1])
        return date(year, month, day)

    #  Новое событие
    def add_event(self, text, time_, period, is_all_day, type_id):
        self.cur = sqlite3.connect("CalendarBase.db")
        cursor = self.cur.cursor()
        # Получаем идентификатор новой строки
        result_id_cur = cursor.execute("""SELECT max(event_id) + 1  FROM event""")
        result_id = result_id_cur.fetchall()
        # Вставляем данные в таблицу
        result = cursor.execute("""INSERT INTO event 
                            (event_id, event_def, date_time, period, is_all_day, type_id)
                             VALUES(?, ? ,? ,?, ?, ?)""", (result_id[0][0], text, time_, period,
                                                           is_all_day, type_id,)).fetchall()
        self.cur.commit()  # Сохраняем изменения
        self.set_date()

    # Изменение события
    def update_event_(self, text, time_, period, is_all_day, type_id, id):
        self.cur = sqlite3.connect("CalendarBase.db")
        cursor = self.cur.cursor()
        result = cursor.execute("""UPDATE event 
                                     SET event_def = ?, 
                                         date_time = ?, 
                                         period = ?, 
                                         is_all_day = ?, 
                                         type_id = ?
                                     WHERE event_id = ?""",
                                (text, time_, period, is_all_day, type_id, id,)).fetchall()
        self.cur.commit()  # Сохраняем изменения
        self.set_date()

    # Удаление события
    def del_event(self, type_id):
        self.cur = sqlite3.connect("CalendarBase.db")
        cursor = self.cur.cursor()
        result = cursor.execute("""DELETE FROM event
                                     WHERE event_id = ?""", (type_id,)).fetchall()
        self.cur.commit()   # Сохраняем изменения
        self.set_date()





    def update_event(self, v_all_day, events_day_or_all_day, date_): # Считывание действий
        index = events_day_or_all_day.currentRow()                   # пользователя
        date_str = date_.strftime('%Y-%m-%d')
        result = self.cur.execute("""SELECT ev.event_id, ev.event_def, ev.date_time, ev.period,
         ev.is_all_day, ev.type_id
                  FROM event ev, type tp
                    WHERE ev.type_id = tp.type_id
                      AND date(ev.date_time) = date(?)
                      AND ev.is_all_day = ?
                          order by date_time ASC""", (date_str, v_all_day)).fetchall()
        id = result[index][0]
        text = result[index][1]
        date_time = result[index][2]
        period = result[index][3]
        is_all_day = result[index][4]
        type_id = result[index][5]
        globals()["tek_znach"] = (id, text, date_time, period, is_all_day, type_id)

        self.ad.text_event.setText(tek_znach[1])
        self.ad.start_event_time.show()
        if is_all_day == 1:
            self.ad.check_all_day.setCheckState(Qt.Checked)
            self.ad.duration_event.setReadOnly(True)
            self.ad.start_event_time.setTime(time(00, 00))
            self.ad.duration_event.setTime(time(00, 00))
            self.ad.duration = time(00, 00)
            self.ad.start_event_time.hide()
        else:
            self.ad.check_all_day.setCheckState(Qt.Unchecked)
            h = int(date_time[-5] + date_time[-4])
            m = int(date_time[-2] + date_time[-1])
            self.ad.start_event_time.setTime(time(h, m))
            h = int(period.split(':')[0])
            m = int(period.split(':')[1])
            self.ad.duration = time(h, m)
            self.ad.duration_event.setTime(time(h, m))
        year = int(date_time[0] + date_time[1] + date_time[2] + date_time[3])
        month = int(date_time[5] + date_time[6])
        day = int(date_time[8] + date_time[9])
        self.ad.start_event_date.setDate(date(year, month, day))
        self.type_event_update(type_id)
        globals()["add_or_update"] = 'update'
        self.ad.button_delete.show()
        self.ad.exec_()

    def type_event_update(self, type_id):
        result2 = self.cur.execute("""SELECT type_name FROM type""").fetchall()
        self.ad.type_event.clear()
        for i in range(len(result2)):
            if i == 0:
                self.ad.type_event.addItem(result2[type_id - 1][0])
                if type_id != 1:
                   self.ad.type_event.addItem(result2[0][0])
            else:
                if i + 1 != type_id:
                    self.ad.type_event.addItem(result2[i][0])

    def create_window(self):
        self.ad.duration = time(1, 00)
        self.ad.text_event.setText('')
        self.ad.duration_event.setTime(self.ad.duration)
        self.ad.start_event_date.setDate(current_date)
        self.ad.start_event_time.setTime(time(datetime.today().hour, datetime.today().minute))
        self.ad.button_delete.hide()
        self.type_event_update(4)
        globals()["add_or_update"] = 'add'
        self.ad.exec_()

    def add_ev(self):
        text = self.ad.text_event.toPlainText()
        date_ = self.ad.start_event_date.text().replace('.', '-')
        time_ = self.ad.start_event_time.text()
        date_time = date_ + ' ' + time_
        type_id = self.ad.type_event.currentText()
        result = self.cur.execute("""SELECT type_id FROM type
                                    WHERE type_name = ?  """, (type_id,)).fetchall()
        type_id = result[0][0]
        self.add_event(text, date_time, self.ad.duration.strftime('%H:%M'), 0, type_id)
        self.set_date()
        self.ad.close()


class Add_delete_edit_event(QDialog, Ui_add_delete_edit):
    def __init__(self, root):
        super().__init__(root)
        self.setupUi(self)
        self.setFixedSize(470, 243)
        self.ca_ = root
        self.position_check_all_day = 0
        self.start_event_date.setCalendarPopup(True)
        self.button_save.clicked.connect(self.save)
        self.button_delete.clicked.connect(self.delete)
        self.button_cancel.clicked.connect(self.cancel)
        self.check_all_day.stateChanged.connect(self.changeTitle)
        self.start_event_date.setDisplayFormat("yyyy.MM.dd")
        self.start_event_time.setDisplayFormat("HH:mm")
        self.duration_event.setDisplayFormat("HH:mm")

    def changeTitle(self, state):
        if state == Qt.Checked:
            self.duration_event.setReadOnly(True)
            self.start_event_time.hide()
            self.duration_event.setTime(time(00, 00))
            self.position_check_all_day = 1
        else:
            self.duration_event.setReadOnly(False)
            self.start_event_time.show()
            self.duration_event.setTime(self.duration)
            self.position_check_all_day = 0

    def delete(self):
        self.ca_.del_event(tek_znach[0])
        self.close()

    def cancel(self):
        self.close()

    def save(self):
        if add_or_update == 'update':
            text = self.text_event.toPlainText()
            date_ = self.start_event_date.text().replace('.', '-')
            time_ = self.start_event_time.text()
            period = self.duration_event.text()
            date_time = date_ + ' ' + time_
            type_id = self.type_event.currentText()
            id_ = tek_znach[0]
            result = self.ca_.cur.execute("""SELECT type_id FROM type
                                                WHERE type_name = ?  """, (type_id,)).fetchall()
            type_id = result[0][0]
            self.ca_.update_event_(text, date_time, period, self.position_check_all_day, type_id,
                                   id_)
            self.ca_.set_date()
            self.close()
        elif add_or_update == 'add':
            self.ca_.add_ev()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ca = Calendar()
    ca.show()
    sys.exit(app.exec_())